// negar kazemi    40223064

#include <stdio.h>
#include <math.h>
double x1, x2;
int solver (double a, double b, double c);
int main()
{   
    double a, b, c;
    printf ("please enter <<a>> for the equation (ax^2+bx+c)\n");
    scanf("%lf",&a);
    printf ("please enter <<b>> for the equation (ax^2+bx+c)\n");
    scanf("%lf",&b);
    printf ("please enter <<c>> for the equation (ax^2+bx+c)\n");
    scanf("%lf",&c);
    if(a==0 && b==0)
        printf("wrong numbers");
    else if((b*b)-(4*a*c)<0)
        printf("this equation has no real roots");
    else
    {
        if (solver(a,b,c)==1)
            printf("this equation has one real root\nx=%lf",x1);
        else if (solver(a,b,c)==2)
            printf("this equation has two real roots\nx1=%lf\nx2=%lf",x1, x2); 
    }
}

int solver (double a, double b, double c)
{
    
        double d=sqrt ((b*b)-(4*a*c));
        x1= ((-b+d)/2*a);
        x2= ((-b-d)/2*a);
        if (x1==x2)
            return 1;
        else
            return 2;
}
    

